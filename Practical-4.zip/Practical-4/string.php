<?php
//  $str="Hello ";

//  $r = strpos($str,"d",-1);
//  echo substr($str,3);
//     //echo $r;

//     $tan="tanmay";
//     echo $str.=$tan;    

// $cars = array("Volvo", "BMW", "Toyota");
// $arrlength = count($cars);
// for($x = 0; $x < $arrlength; $x++) {
// echo $cars[$x];
// echo "<br>";
// }

// $age = array("Peter"=>"35", "Ben"=>"37", "Joe"=>"43");
// foreach($age as $x => $x_value) {
// echo " $x $x_value";
// echo "<br>";
// }

// $a=array("A","Cat","Dog","A","Dog");
// print_r(array_count_values($a));

// $a=array("A","Cat","Dog","A","Dog");
// $cnt = array_count_values($a);
// echo $cnt['A'];

// $cars = array (array("Volvo",22,18), array("BMW",15,13), 
// array("Saab",5,2), array("Land Rover",17,15));
// for($row = 0; $row < 4; $row++){
// echo "<p><b>Row number $row</b></p>";
// echo "<ul>";
// for ($col = 0; $col < 3; $col++) {
// echo "<li>".$cars[$row][$col]."</li>";
// }
// echo "</ul>";
// }
// $shape = "round";
// $array = array("cover" => "bird", "shape" => "rectangular");
// extract($array, EXTR_PREFIX_SAME, "book");
// echo "Cover: $cover, Book Shape: $book_shape, Shape: $shape";

// $a = array(1, 2, array("a", "b", "c"));
// var_dump($a);
// $a = array ('a' => 'apple', 'b' => 'banana', 'c' => array ('x', 'y', 'z'));
// print_r ($a);
echo "Today is " . date("l");
?>