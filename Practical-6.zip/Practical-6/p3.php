
 <?php
// echo "Warning error"';
// include ("external_file.php");
?> 



 <?php
// $a="Defined error";
// echo "Notice error";
// echo $b;
//Notice: Undefined variable: b in D:\study\MCA\SEM-3\PHP\htdocs\Practical-6\p3.php on line 12
?>

<?php
// function sub()
// {
// $sub=6-1;
// echo "The sub= ".$sub;
// }
// div();
//Fatal error: Uncaught Error: Call to undefined function div() in D:\study\MCA\SEM-3\PHP\htdocs\Practical-6\p3.php:23 Stack trace: #0 {main} thrown in D:\study\MCA\SEM-3\PHP\htdocs\Practical-6\p3.php on line 23

?>
